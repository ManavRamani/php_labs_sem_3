<?php
$n = 5;

for ($i = $n; $i > 0; $i--) {
    for ($j = 0; $j < $i; $j++) {
        echo "&nbsp;&nbsp;*";
    }
    echo "<br> ";
}
?>