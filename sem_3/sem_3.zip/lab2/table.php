<?php

$n=10;

for($i=1;$i<=10;$i++){
    echo("$n * $i = " . $n*$i . "<br>");
}


?>